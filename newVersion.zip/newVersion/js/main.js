// Initializations
const account = new Account(0, 0, 0);

// To Deposit
function toDeposit() {
  deposit = parseFloat(document.getElementById("deposit_input").value);
  account.calcDeposit(deposit)
}

const buttonDeposit = document.getElementById('deposit_button');
buttonDeposit.addEventListener('click', toDeposit);

// Calc Balance
function calcBalance() {
  balance = account.balance;
  document.getElementById('balance_input').value = balance;
}

const Button_saldo = document.getElementById('balance_button');
Button_saldo.addEventListener('click', calcBalance);

// Retirement
function retirar() {
  valorRetiro = parseFloat(document.getElementById("retirar_boton").value);
  cuenta.retiro = valorRetiro;
}

const Button_retiro = document.getElementById('retirar_boton');
Button_retiro.addEventListener('click', retirar);

